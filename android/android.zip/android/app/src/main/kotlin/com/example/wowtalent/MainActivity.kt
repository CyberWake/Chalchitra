package com.example.wowtalent

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
